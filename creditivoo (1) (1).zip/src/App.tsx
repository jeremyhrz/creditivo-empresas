/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  TrendingUp,
  Smartphone,
  Building,
  Check,
  Building2,
  ShieldCheck,
  ChevronRight,
  HelpCircle,
  FileCheck2,
  Info
} from 'lucide-react';

// Data lists
import { SEGMENTS, BENEFITS, STEPS } from './landingData';

// Subcomponents
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import SegmentCard from './components/SegmentCard';
import BenefitCard from './components/BenefitCard';
import StepCard from './components/StepCard';
import RequirementTabs from './components/RequirementTabs';
import LeadForm from './components/LeadForm';
import FAQAccordion from './components/FAQAccordion';
import CTASection from './components/CTASection';
import Footer from './components/Footer';

export default function App() {
  // State to manage pre-selected request type in the Lead Form
  const [selectedLeadType, setSelectedLeadType] = useState<'mayorista' | 'emprendedor' | 'nomina' | 'empresa' | null>(null);

  // Smooth scroll utility with an offset of 80px (for the sticky navbar)
  const handleScrollToSection = (elementSelector: string) => {
    const target = document.querySelector(elementSelector);
    if (target) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = target.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Specific handler when user clicks a segment card or CTA button
  const handleActionClick = (profileId: 'mayorista' | 'emprendedor' | 'nomina' | 'empresa') => {
    setSelectedLeadType(profileId);
    handleScrollToSection('#formulario-solicitud-lead');
  };

  const menuActions = {
    onCtaClick: () => handleActionClick('mayorista'),
    onCompanyClick: () => handleActionClick('empresa')
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-gray-800 antialiased overflow-x-hidden selection:bg-[#10D66B] selection:text-white">
      
      {/* 1. Header Navigation Bar */}
      <Navbar onCtaClick={() => handleActionClick('mayorista')} onCompanyClick={() => handleActionClick('empresa')} />

      {/* 2. Hero Section */}
      <HeroSection onCtaClick={() => handleActionClick('mayorista')} onCompanyClick={() => handleActionClick('empresa')} />

      {/* 3. Bloque de Segmentos ("Elige el Creditivoo que va contigo") */}
      <section id="soluciones" className="py-16 md:py-20 bg-white border-t border-b border-gray-150/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-12">
          
          <div className="max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-black text-[#006B3F] bg-emerald-100/60 px-3.5 py-1.5 rounded-full uppercase tracking-widest leading-none">
              Opciones de financiamiento
            </span>
            <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight leading-none">
              Elige el Creditivoo que va contigo
            </h2>
            <p className="text-sm md:text-base text-gray-500 leading-relaxed">
              Descubre las tres formas de activar una línea de compra evaluada especialmente para tu caso, según tu perfil o tu actividad comercial.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 items-stretch pt-2">
            {SEGMENTS.map((segment) => (
              <SegmentCard
                key={segment.id}
                segment={segment}
                onSelect={(id) => handleActionClick(id as any)}
              />
            ))}
          </div>

        </div>
      </section>

      {/* 4. Bloque "Qué es Creditivoo" */}
      <section className="py-16 md:py-20 bg-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-12 items-center">
            
            {/* Benefits Text Column */}
            <div className="lg:col-span-5 space-y-5 text-left">
              <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full uppercase tracking-widest leading-none">
                ¿Qué es Creditivoo?
              </span>
              <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight leading-none">
                Una forma más simple de acceder a tus productos en IVOO
              </h2>
              <p className="text-sm text-gray-500 leading-relaxed">
                Creditivoo no es un banco convencional ni una tarjeta bancaria tradicional. Consiste en una solución de financiamiento propia, directa y segura de IVOO, pensada para agilizar el acceso a la mejor tecnología, electrodomésticos y bienes de hogar. Evaluamos tu perfil y te asignamos una línea de compra disponible para canjear en cualquiera de nuestros canales.
              </p>
              
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100/50 flex items-start gap-3">
                <Info className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <p className="text-xs text-gray-400 leading-normal">
                  Puedes aplicar seas cliente frecuente o sea tu primera vez con nosotros. Tu historial de compras nos ayuda a conocerte mejor, pero no es de carácter obligatorio.
                </p>
              </div>
            </div>

            {/* Benefits Cards column */}
            <div className="lg:col-span-7 space-y-4">
              {BENEFITS.map((benefit) => (
                <BenefitCard key={benefit.id} benefit={benefit} />
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* 5. Bloque "Cómo funciona" */}
      <section id="como-funciona" className="py-16 md:py-20 bg-white border-t border-b border-gray-150/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-12">
          
          <div className="max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-black text-[#006B3F] bg-white border border-gray-200 px-3.5 py-1.5 rounded-full uppercase tracking-widest leading-none">
              Paso a paso
            </span>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight leading-none">
              Solicitar tu línea Creditivoo es sumamente fácil
            </h2>
            <p className="text-sm text-gray-500 leading-relaxed">
              Un flujo de registro digital pensado en tu comodidad. Sube tus documentos desde el celular y nuestro equipo procesará de forma manual tu postulación.
            </p>
          </div>

          {/* Timeline Process Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 md:gap-6 pt-6">
            {STEPS.map((step) => (
              <StepCard key={step.number} step={step} />
            ))}
          </div>

          <div className="pt-4">
            <button
              onClick={() => handleActionClick('mayorista')}
              className="px-8 py-3.5 bg-[#006B3F] hover:bg-[#005530] text-white text-sm font-bold rounded-xl shadow-lg hover:shadow-green-200 transition-all cursor-pointer inline-flex items-center gap-1.5 group"
            >
              <span>Comenzar solicitud ya</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
            <p className="text-[11px] text-gray-400 mt-2">
              *El tiempo de evaluación de recaudos depende del perfil, sujeto al horario comercial de analistas de Creditivoo.
            </p>
          </div>

        </div>
      </section>

      {/* 6. Bloque Específico: Creditivoo Mayorista */}
      <section className="py-16 md:py-24 bg-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-12 items-center">
            
            {/* Visual element / details grid on the left */}
            <div className="lg:col-span-6 space-y-4 text-left order-2 lg:order-1">
              <div className="p-6 bg-white border border-gray-100/80 rounded-3xl space-y-4 shadow-sm hover:border-[#10D66B]/50 transition-all">
                <h4 className="text-xs font-extrabold text-[#006B3F] uppercase tracking-widest">
                  Estructura de Beneficios Exclusivos
                </h4>
                
                <div className="space-y-3">
                  {[
                    'Asignación manual basada en tu perfil de ventas y compras.',
                    'No necesitas tener historial previo de compras en IVOO para aplicar.',
                    'Cuentas con la confianza y solidez del inventario directo de IVOO.',
                    'Perfecto para compras por volumen, re-abastecimiento o renovación tecnológica corporativa.'
                  ].map((item, idx) => (
                    <div key={idx} className="flex gap-2.5 items-start text-sm text-gray-600">
                      <span className="p-0.5 bg-emerald-100 text-[#006B3F] rounded-full shrink-0 mt-0.5">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-150 pt-4 space-y-2">
                  <p className="text-xs font-extrabold text-gray-400 uppercase tracking-widest">Requisitos Clave</p>
                  <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 font-semibold">
                    <span>• Cédula de Identidad</span>
                    <span>• RIF Obligatorio</span>
                    <span>• Soportes de Venta</span>
                    <span>• Registro Mercantil (opcional)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Content text description and triggers on the right */}
            <div className="lg:col-span-6 space-y-6 text-left order-1 lg:order-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full border border-emerald-100">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Especial para Distribuidores</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight leading-none">
                Creditivoo Mayorista
              </h2>
              <p className="text-base text-gray-900 font-bold leading-normal">
                Compra comercial con una línea pensada para mover inventario, surtir tu negocio o ampliar tus oportunidades de crecimiento.
              </p>
              <p className="text-sm text-gray-500 leading-relaxed">
                Toda empresa o comercio requiere velocidad de suministro para no estancar sus canales. Puedes aplicar seas cliente actual de IVOO o estés comenzando tu relación comercial con nosotros. Si cuentas con historial de compras, te ayudará a acelerar la evaluación del analista. Si no lo tienes, igual puedes continuar con tu solicitud digital.
              </p>
              
              <div className="pt-2">
                <button
                  onClick={() => handleActionClick('mayorista')}
                  className="px-6 py-3 bg-[#10D66B] hover:bg-[#00B555] text-white font-extrabold text-sm rounded-xl shadow-md cursor-pointer inline-flex items-center gap-2 group"
                >
                  <span>Solicitar Creditivoo Mayorista</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 7. Bloque Específico: Creditivoo Emprendedores */}
      <section className="py-16 md:py-24 bg-white border-t border-b border-gray-150/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-12 items-center">
            
            {/* Content text description on the left */}
            <div className="lg:col-span-6 space-y-6 text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-cyan-50 text-cyan-700 text-xs font-bold rounded-full border border-cyan-100">
                <Smartphone className="w-3.5 h-3.5" />
                <span>Comerciantes Independientes</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight leading-none">
                Creditivoo Emprendedores
              </h2>
              <p className="text-base text-gray-900 font-bold leading-snug">
                Para quienes compran, venden, se mueven y hacen crecer su negocio digital u offline desde donde se encuentren.
              </p>
              <p className="text-sm text-gray-500 leading-relaxed">
                Si vendes tus productos a través de Instagram, estados y mensajería de WhatsApp, tiendas físicas temporales, Marketplace o a través de redes de referidos personales, puedes solicitar tu Creditivoo como comerciante o cliente comercial independiente. No necesitas estar registrado como firma corporativa mayor, solo requerimos tu RIF personal al día.
              </p>

              {/* Dynamic bullets */}
              <div className="space-y-2.5">
                {[
                  'No es necesario disponer de una empresa registrada.',
                  'Demuestra tu actividad comercial actual con pantallazos, catálogos, redes sociales o facturas simples.',
                  'Línea asignada a tu persona digital conforme a la evaluación de riesgos.',
                  'Compra tecnología o electrodomésticos para revender a tus clientes con margen de ganancia.'
                ].map((bul, idx) => (
                  <div key={idx} className="flex gap-2 items-center text-sm text-gray-600">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 shrink-0"></span>
                    <span>{bul}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2">
                <button
                  onClick={() => handleActionClick('emprendedor')}
                  className="px-6 py-3 bg-[#006B3F] hover:bg-[#005530] text-white font-extrabold text-sm rounded-xl shadow-md cursor-pointer inline-flex items-center gap-2 group"
                >
                  <span>Solicitar como emprendedor</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>

            {/* Visual requirements bullet highlights card on the right */}
            <div className="lg:col-span-6 space-y-4 text-left">
              <div className="p-6 bg-white border border-gray-150 rounded-3xl space-y-4 shadow-sm">
                <h4 className="text-xs font-extrabold text-cyan-700 uppercase tracking-widest flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-[#10D66B]" />
                  <span>Soportes para Emprendedores</span>
                </h4>
                <p className="text-xs text-gray-500 leading-normal">
                  Prepara esta documentación digital básica antes de iniciar el contacto con tu asesor comercial.
                </p>

                <div className="divide-y divide-gray-100">
                  <div className="py-2.5 flex justify-between items-center">
                    <span className="text-sm font-bold text-gray-800">Cédula de Identidad</span>
                    <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full">Obligatorio</span>
                  </div>
                  <div className="py-2.5 flex justify-between items-center">
                    <span className="text-sm font-bold text-gray-800">RIF Personal Vigente</span>
                    <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full">Obligatorio</span>
                  </div>
                  <div className="py-2.5 flex justify-between items-center">
                    <span className="text-sm font-bold text-gray-800">Prueba de Vida (Selfie)</span>
                    <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full">Obligatorio</span>
                  </div>
                  <div className="py-2.5 flex justify-between items-center">
                    <span className="text-sm font-bold text-gray-800">Redes o Capture de Ventas</span>
                    <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full">Obligatorio</span>
                  </div>
                </div>

                <div className="p-3 bg-cyan-50/50 border border-cyan-100/30 rounded-2xl">
                  <p className="text-[11px] text-cyan-800 leading-normal">
                    <strong>Tip de Aprobación:</strong> Subir capturas claras de tus últimos chats de venta o de tu perfil comercial de Instagram incrementa las probabilidades de conseguir una mayor línea autorizada.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 8. Bloque Específico: Creditivoo Nómina */}
      <section className="py-16 md:py-24 bg-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-12 items-center">
            
            {/* Split cards on the left (Corporatives / Employees) */}
            <div className="lg:col-span-6 space-y-5 text-left order-2 lg:order-1">
              
              {/* Employers benefit card */}
              <div className="p-5 bg-indigo-50/50 border border-indigo-100/30 rounded-2xl">
                <span className="text-[10px] font-black text-indigo-700 uppercase tracking-widest block mb-1">Para la Empresa Afiliada</span>
                <p className="text-sm font-bold text-gray-900 leading-snug mb-1">Cero Carga Administrativa o Financiera</p>
                <p className="text-xs text-gray-500 leading-relaxed">
                  No compromete flujo de caja, no implica adelantos de sueldo directos, y no requiere descuento por nómina (el empleado paga directamente). Su corporación únicamente valida el estatus o relación laboral del colaborador para agilizar la aprobación.
                </p>
              </div>

              {/* Colleague benefit card */}
              <div className="p-5 bg-emerald-50/50 border border-emerald-100/30 rounded-2xl">
                <span className="text-[10px] font-black text-[#006B3F] uppercase tracking-widest block mb-1">Para el Colaborador</span>
                <p className="text-sm font-bold text-gray-900 leading-snug mb-1">Acceso Directo con Menores Trámites</p>
                <p className="text-xs text-gray-500 leading-relaxed">
                  Consigue una línea de crédito disponible para canjear en computadoras, electrodomésticos, repuestos u otras necesidades en IVOO, simplemente verificando que perteneces a la empresa de nuestro listado.
                </p>
              </div>

            </div>

            {/* Main content descriptions on the right */}
            <div className="lg:col-span-6 space-y-6 text-left order-1 lg:order-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-bold rounded-full border border-indigo-100">
                <Building className="w-3.5 h-3.5" />
                <span>Beneficio Laboral de Vanguardia</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight leading-none">
                Creditivoo Nómina
              </h2>
              <p className="text-base text-gray-900 font-bold leading-normal">
                Un beneficio social y comercial alternativo para colaboradores de empresas afiliadas.
              </p>
              <p className="text-sm text-gray-500 leading-relaxed">
                Creditivoo Nómina permite que las empresas afiliadas brinden a todo su personal activo una opción de financiamiento privado de alto valor. En este MVP, su empresa actúa únicamente como validador de la relación laboral del colaborador. No se descuentan fondos del sueldo tradicional, facilitando las decisiones financieras de su equipo.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => handleActionClick('empresa')}
                  className="px-6 py-3 bg-[#006B3F] hover:bg-[#005530] text-white font-extrabold text-sm rounded-xl shadow-md cursor-pointer transition-all"
                >
                  Afiliar mi empresa
                </button>
                <button
                  onClick={() => handleActionClick('nomina')}
                  className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-extrabold text-sm rounded-xl transition-all cursor-pointer"
                >
                  Activar como colaborador
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 9. Bloque Para Empresas afiliadas / Aliados de Creditivoo */}
      <section id="empresas" className="py-16 md:py-20 bg-white border-t border-b border-gray-150/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-3.5 py-1.5 rounded-full uppercase tracking-widest leading-none">
              Programa de Aliados Corporativos
            </span>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight leading-none">
              Ofrece Creditivoo Nómina a tu equipo de trabajo
            </h2>
            <p className="text-sm text-gray-500 leading-relaxed">
              Suma un beneficio laboral corporativo de primer nivel para tus trabajadores sin incurrir en costos tradicionales de administración crediticia o de descuento de salarios.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: 'Más valor para tu equipo',
                desc: 'Incentiva a tu personal brindándoles un beneficio robusto y útil para adquirir tecnología u hogar sin complejidades.'
              },
              {
                title: 'Validación laboral simple',
                desc: 'La empresa únicamente valida que el colaborador pertenece activamente a la organización mediante un listado o código.'
              },
              {
                title: 'Sin descuento de sueldo',
                desc: 'En este MVP, el pago lo administra directamente el empleado ante Creditivoo, eximiendo de pasivos a tu administración.'
              },
              {
                title: 'Activación y pilotos controlados',
                desc: 'Empieza con un grupo piloto de colaboradores clave para medir adopción y afinar el proceso corporativo.'
              }
            ].map((card, idx) => (
              <div key={idx} className="p-6 bg-white border border-gray-100 rounded-2xl text-left space-y-2 hover:shadow-md transition-shadow">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm">
                  {idx + 1}
                </div>
                <h4 className="font-extrabold text-gray-900 text-base">{card.title}</h4>
                <p className="text-xs text-gray-500 leading-relaxed">{card.desc}</p>
              </div>
            ))}
          </div>

          <div className="text-center pt-2">
            <button
              onClick={() => handleActionClick('empresa')}
              className="px-8 py-3.5 bg-[#10D66B] hover:bg-[#00B555] text-white font-black text-sm rounded-xl shadow-lg shadow-[#10D66B]/15 hover:shadow-emerald-500/20 transition-all cursor-pointer inline-flex items-center gap-1.5"
            >
              <span>Quiero afiliar mi empresa</span>
            </button>
          </div>

        </div>
      </section>

      {/* 10. Sección de Documentos / Requisitos (RequirementTabs) */}
      <section id="requisitos" className="py-16 md:py-20 bg-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-3.5 py-1.5 rounded-full uppercase tracking-widest leading-none">
              Recaudación básica
            </span>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight leading-none">
              Requisitos y recaudos según tu perfil
            </h2>
            <p className="text-sm text-gray-500 leading-relaxed">
              Selecciona tu modalidad específica debajo para detallar la recopilación de documentos requerida para evaluar tu perfil.
            </p>
          </div>

          <RequirementTabs />

        </div>
      </section>

      {/* 11. Formulario Principal de Leads (LeadForm) */}
      <section id="formulario-solicitud-lead" className="py-16 md:py-20 bg-white border-t border-b border-gray-150/40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          
          <div className="text-center space-y-2">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-widest text-[#006B3F]">Postulación Digital MVP</span>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight leading-none">
              Solicita tu línea hoy mismo
            </h2>
            <p className="text-sm text-gray-500 max-w-md mx-auto">
              Nuestros asesores y analistas de Creditivoo se encargarán de guiarte paso a paso por WhatsApp.
            </p>
          </div>

          <LeadForm preSelectedType={selectedLeadType} />

        </div>
      </section>

      {/* 12. Sección de Preguntas Frecuentes (FAQAccordion) */}
      <section id="preguntas-frecuentes" className="py-16 md:py-20 bg-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-3.5 py-1.5 rounded-full uppercase tracking-widest leading-none">
              Resuelve tus dudas
            </span>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight leading-none">
              Preguntas frecuentes
            </h2>
            <p className="text-sm text-gray-500 leading-relaxed">
              Encuentra respuestas rápidas y oportunas a las dudas e interrogantes más comunes con relación a la línea Creditivoo de IVOO.
            </p>
          </div>

          <FAQAccordion />

        </div>
      </section>

      {/* 13. CTA Final */}
      <CTASection
        onCtaClick={() => handleActionClick('mayorista')}
        onCompanyClick={() => handleActionClick('empresa')}
      />

      {/* 14. Footer */}
      <Footer onScrollToElement={handleScrollToSection} />

    </div>
  );
}
