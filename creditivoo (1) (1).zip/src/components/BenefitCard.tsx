/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Sliders, Smartphone, CheckCircle, SmartphoneIcon, Percent, HelpCircle } from 'lucide-react';
import { Benefit } from '../types';

interface BenefitCardProps {
  key?: any;
  benefit: Benefit;
}

export default function BenefitCard({ benefit }: BenefitCardProps) {
  const getIcon = () => {
    switch (benefit.id) {
      case 'perfil':
        return <Sliders className="w-5 h-5 text-[#006B3F]" />;
      case 'celular':
        return <Smartphone className="w-5 h-5 text-[#10D66B]" />;
      case 'ivoo':
        return <CheckCircle className="w-5 h-5 text-emerald-600" />;
      default:
        return <Sparkles className="w-5 h-5 text-emerald-500" />;
    }
  };

  return (
    <div className="flex gap-4 p-5 sm:p-6 bg-white border border-gray-100 rounded-2xl hover:shadow-lg hover:shadow-emerald-100/10 hover:border-emerald-100 transition-all duration-300">
      <div className="flex-shrink-0 p-3 h-11 w-11 rounded-xl bg-emerald-50/50 flex items-center justify-center border border-emerald-100/20">
        {getIcon()}
      </div>
      <div>
        <h4 className="font-bold text-gray-900 text-base leading-snug mb-1">
          {benefit.title}
        </h4>
        <p className="text-sm text-gray-500 leading-relaxed">
          {benefit.description}
        </p>
      </div>
    </div>
  );
}
