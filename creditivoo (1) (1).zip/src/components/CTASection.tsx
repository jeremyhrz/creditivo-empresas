/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ShieldCheck, HelpCircle } from 'lucide-react';

interface CTASectionProps {
  onCtaClick: () => void;
  onCompanyClick: () => void;
}

export default function CTASection({ onCtaClick, onCompanyClick }: CTASectionProps) {
  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-white to-emerald-50/[0.15] border-t border-gray-100 overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative bg-gradient-to-br from-[#006B3F] to-[#005530] text-white rounded-[32px] p-8 md:p-12 overflow-hidden shadow-2xl border border-emerald-800/20 text-center">
          
          {/* Ambient light circles background inside CTA box */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-400/10 rounded-full blur-2xl -z-10 translate-x-1/3 -translate-y-1/3"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#10D66B]/10 rounded-full blur-2xl -z-10 -translate-x-1/4 translate-y-1/4"></div>

          <div className="max-w-2xl mx-auto space-y-5">
            <span className="inline-block px-3 py-1 bg-white/10 rounded-full text-xs font-bold text-emerald-300 uppercase tracking-widest leading-none">
              Inicia tu proceso hoy
            </span>
            
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black tracking-tight leading-none text-white">
              ¿Listo para activar tu línea Creditivoo?
            </h2>
            
            <p className="text-sm md:text-base text-emerald-100/90 leading-relaxed max-w-lg mx-auto">
              Elige tu perfil (Mayorista, Emprendedor o Colaborador), carga tus recaudos digitales y deja que nuestro equipo analice tu perfil comercial para asignarte una línea.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-3.5 justify-center pt-4 md:pt-6">
              <button
                onClick={onCtaClick}
                className="px-8 py-4 bg-[#10D66B] hover:bg-[#00B555] text-white font-black text-sm rounded-xl transition-all shadow-lg hover:shadow-emerald-500/10 flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>Solicitar Creditivoo</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
              
              <button
                onClick={onCompanyClick}
                className="px-8 py-4 bg-emerald-950/40 hover:bg-emerald-950/60 text-emerald-200 font-bold text-sm rounded-xl border border-emerald-700/40 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Afiliar mi empresa</span>
              </button>
            </div>

            {/* Microcopy disclaimer */}
            <p className="text-[11px] text-emerald-300/80 leading-normal max-w-sm mx-auto pt-3">
              *La asignación de línea se realiza por evaluación manual, no por aprobación automática inmediata. Sin cobros ocultos ni papeleo bancario.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
