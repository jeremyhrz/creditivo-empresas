/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { FAQS } from '../landingData';

export default function FAQAccordion() {
  const [openId, setOpenId] = useState<number | null>(1); // default open first

  const toggleFAQ = (id: number) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-3">
      {FAQS.map((faq) => {
        const isOpen = openId === faq.id;
        return (
          <div
            key={faq.id}
            className={`border rounded-2xl transition-all duration-300 ${
              isOpen
                ? 'bg-emerald-50/[0.15] border-emerald-100 shadow-sm'
                : 'bg-white border-gray-100/80 hover:border-gray-200'
            }`}
          >
            <button
              onClick={() => toggleFAQ(faq.id)}
              className="w-full flex items-center justify-between p-5 text-left font-bold text-gray-800 transition-colors focus:outline-none cursor-pointer"
            >
              <div className="flex gap-3 items-start">
                <HelpCircle className={`w-5 h-5 mt-0.5 shrink-0 transition-colors ${isOpen ? 'text-[#10D66B]' : 'text-gray-400'}`} />
                <span className="text-sm md:text-base leading-snug">{faq.question}</span>
              </div>
              <ChevronDown
                className={`w-5 h-5 shrink-0 text-gray-400 transition-transform duration-300 ${
                  isOpen ? 'rotate-180 text-[#10D66B]' : ''
                }`}
              />
            </button>

            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: 'easeInOut' }}
                  className="overflow-hidden"
                >
                  <div className="px-5 pb-5 pt-1 text-sm text-gray-500 leading-relaxed border-t border-dashed border-gray-100 ml-8">
                    {faq.answer}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
