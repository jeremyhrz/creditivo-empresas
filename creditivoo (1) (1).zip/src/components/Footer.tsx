/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Mail, MessageSquare, ShieldCheck, HelpCircle, FileSignature, Globe } from 'lucide-react';
import CreditivooLogo from './CreditivooLogo';

interface FooterProps {
  onScrollToElement: (selector: string) => void;
}

export default function Footer({ onScrollToElement }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    onScrollToElement(href);
  };

  return (
    <footer className="bg-white border-t border-gray-100/90 pt-16 pb-12 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-8 pb-12 border-b border-gray-150">
          
          {/* Logo, text & disclaimer section */}
          <div className="md:col-span-12 lg:col-span-5 space-y-4">
            <CreditivooLogo className="h-8" />
            <p className="text-sm text-gray-500 max-w-sm leading-relaxed">
              Creditivoo es la solución de financiamiento propio de IVOO diseñada para facilitar la adquisición de tecnología, electrodomésticos, hogar, entretenimiento y estilo de vida.
            </p>
            <div className="p-3.5 bg-gray-50 rounded-2xl border border-gray-100/50 max-w-sm flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <p className="text-[11px] text-gray-400 leading-normal">
                <strong>Aviso Legal:</strong> Creditivoo no es una entidad bancaria tradicional ni emite tarjetas de crédito de uso universal. Líneas de compra sujetas a debida evaluación de riesgos y consignación digital de documentos.
              </p>
            </div>
          </div>

          {/* Solution & Site Directory Links */}
          <div className="md:col-span-4 lg:col-span-2 space-y-4">
            <h5 className="text-xs font-black text-gray-900 uppercase tracking-widest">
              Directorio
            </h5>
            <ul className="space-y-2 text-sm">
              {[
                { name: 'Inicio', href: '#inicio' },
                { name: 'Soluciones', href: '#soluciones' },
                { name: 'Cómo funciona', href: '#como-funciona' },
                { name: 'Soporte', href: '#preguntas-frecuentes' }
              ].map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    onClick={(e) => handleLinkClick(e, link.href)}
                    className="text-gray-500 hover:text-[#10D66B] transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Pages */}
          <div className="md:col-span-4 lg:col-span-2 space-y-4">
            <h5 className="text-xs font-black text-gray-900 uppercase tracking-widest">
              Legal
            </h5>
            <ul className="space-y-2 text-sm">
              {[
                { name: 'Requisitos', href: '#requisitos' },
                { name: 'Empresas Aliadas', href: '#empresas' },
                { name: 'Términos & Condiciones', href: '#terminos' },
                { name: 'Política de Privacidad', href: '#privacidad' }
              ].map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      if (link.href.startsWith('#')) {
                        handleLinkClick(e, link.href);
                      } else {
                        e.preventDefault();
                        alert('Este enlace muestra el texto modelo legal. En producción se abrirá el PDF correspondiente.');
                      }
                    }}
                    className="text-gray-500 hover:text-[#10D66B] transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Context Contact Options */}
          <div className="md:col-span-4 lg:col-span-3 space-y-4">
            <h5 className="text-xs font-black text-gray-900 uppercase tracking-widest">
              Atención Comercial
            </h5>
            <ul className="space-y-3.5 text-sm">
              <li>
                <a
                  href="https://wa.me/584140000000?text=Hola%20Creditivoo,%20deseo%20mayor%20informaci%C3%B3n"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex items-center gap-2 group text-gray-500 hover:text-[#10D66B] transition-colors"
                >
                  <MessageSquare className="w-4.5 h-4.5 text-[#10D66B] group-hover:scale-110 transition-transform" />
                  <div>
                    <p className="font-semibold text-gray-800 leading-none">WhatsApp Oficial</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">+58 (414) IVOO-CRE</p>
                  </div>
                </a>
              </li>
              <li>
                <a
                  href="mailto:soporte@creditivoo.com"
                  className="flex items-center gap-2 group text-gray-500 hover:text-[#10D66B] transition-colors"
                >
                  <Mail className="w-4.5 h-4.5 text-emerald-600 group-hover:scale-110 transition-transform" />
                  <div>
                    <p className="font-semibold text-gray-800 leading-none">Contacto Electrónico</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">solicitudes@creditivoo.com</p>
                  </div>
                </a>
              </li>
              <li>
                <div className="flex gap-2.5 pt-1.5">
                  {['instagram', 'twitter', 'facebook'].map((social) => (
                    <a
                      key={social}
                      href={`https://${social}.com/ivoovenezuela`}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="p-2 bg-gray-50 hover:bg-emerald-50 text-gray-400 hover:text-[#10D66B] hover:border-emerald-100 border border-gray-100 rounded-xl transition-all capitalize text-[11px] font-bold"
                    >
                      {social}
                    </a>
                  ))}
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Lower copyright brand strip */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-400">
          <p>© {currentYear} Creditivoo. Todos los derechos reservados. Desarrollado para IVOO.</p>
          <div className="flex gap-3 align-center font-bold">
            <span className="flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-emerald-600" />
              <span>Sede Central: Valencia, Venezuela.</span>
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
}
