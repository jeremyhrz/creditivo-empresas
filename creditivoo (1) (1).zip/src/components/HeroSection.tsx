/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles, Shield, UserCheck, HelpCircle } from 'lucide-react';
import MobileMockup from './MobileMockup';

interface HeroSectionProps {
  onCtaClick: () => void;
  onCompanyClick: () => void;
}

export default function HeroSection({ onCtaClick, onCompanyClick }: HeroSectionProps) {
  return (
    <section
      id="inicio"
      className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden bg-gradient-to-b from-emerald-50/20 via-white to-white"
    >
      {/* Background ambient orbs */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-[#10D66B]/5 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-emerald-200/10 rounded-full blur-3xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Hero Left Content Column */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Ambient Fintech Spark Tag */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-50 rounded-full border border-emerald-100/30 text-xs font-bold text-[#006B3F] select-none"
            >
              <Sparkles className="w-3.5 h-3.5 fill-[#10D66B] stroke-none animate-pulse" />
              <span>Financiamiento Propio de IVOO • 100% Digital</span>
            </motion.div>

            {/* Powerful Master Query Headings */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="space-y-3"
            >
              <h1 className="text-4xl sm:text-5xl xl:text-6xl font-black text-gray-900 tracking-tight leading-none">
                Creditivoo:{' '}<br className="hidden sm:inline" />
                <span className="text-[#006B3F] bg-gradient-to-r from-[#006B3F] to-[#10D66B] bg-clip-text text-transparent">
                  para eso que quieres lograr, comprar o comenzar.
                </span>
              </h1>
              <p className="text-base sm:text-lg text-gray-700 font-medium leading-relaxed max-w-2xl">
                La línea Creditivoo diseñada para mover tu negocio, tu equipo de colaboradores y tus metas personales.
              </p>
            </motion.div>

            {/* Subtitles & Descriptions */}
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-sm text-gray-500 max-w-xl leading-relaxed"
            >
              Obtén financiamiento directo de IVOO para mayoristas, emprendedores y colaboradores de empresas afiliadas. Solicita tu línea en línea, carga tus soportes y nuestro equipo evaluará tu perfil para asignarte una línea disponible para comprar en tiendas IVOO.
            </motion.p>

            {/* Responsive Action CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-3 pt-2"
            >
              <button
                onClick={onCtaClick}
                className="px-8 py-4 bg-[#10D66B] hover:bg-[#00B555] text-white font-black text-sm rounded-xl shadow-lg shadow-[#10D66B]/20 hover:shadow-[#10D66B]/30 transition-all flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>Solicitar Creditivoo</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
              
              <button
                onClick={onCompanyClick}
                className="px-8 py-4 bg-gray-50 hover:bg-gray-100 text-[#006B3F] font-bold text-sm rounded-xl border border-gray-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Afiliar mi empresa</span>
              </button>
            </motion.div>

            {/* Microcopy Trust Guard Anchor */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="pt-2 flex items-start gap-2.5 text-xs text-gray-400 max-w-lg"
            >
              <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <p className="leading-snug">
                <strong>Sin bancos. Sin vueltas.</strong> Con revisión crediticia humana clara y asignación de línea disponible según el potencial real de tu perfil.
              </p>
            </motion.div>

          </div>

          {/* Hero Right Visuals Column (MobileMockup Container) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-5 flex justify-center py-4 relative"
          >
            <MobileMockup />
          </motion.div>

        </div>
      </div>
    </section>
  );
}
