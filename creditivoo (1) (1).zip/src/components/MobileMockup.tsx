/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, UserCheck, Smartphone, Check, ArrowRight, FileText, Sparkles, Building2, TrendingUp } from 'lucide-react';
import StatusBadge from './StatusBadge';
import CreditivooLogo from './CreditivooLogo';

export default function MobileMockup() {
  const [step, setStep] = useState<number>(1);
  const [selectedProfile, setSelectedProfile] = useState<string>('mayorista');
  const [isSubmittingDoc, setIsSubmittingDoc] = useState<boolean>(false);
  const [docProgress, setDocProgress] = useState<number>(0);

  const startDocUpload = () => {
    setIsSubmittingDoc(true);
    setDocProgress(10);
    const interval = setInterval(() => {
      setDocProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setStep(4);
            setIsSubmittingDoc(false);
          }, 800);
          return 100;
        }
        return prev + 15;
      });
    }, 150);
  };

  const resetSimulator = () => {
    setStep(1);
    setSelectedProfile('mayorista');
    setDocProgress(0);
    setIsSubmittingDoc(false);
  };

  return (
    <div className="relative w-full max-w-[340px] mx-auto xl:max-w-[360px] aspect-[9/18.5] bg-gray-950 rounded-[48px] p-3 shadow-2xl border-4 border-gray-800/80 ring-12 ring-gray-900/10 flex flex-col overflow-visible">
      {/* Notch indicator */}
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 h-5 w-32 bg-gray-950 rounded-b-2xl z-20 flex items-center justify-center">
        <div className="h-1.5 w-12 bg-gray-800 rounded-full mb-1"></div>
      </div>

      {/* Embedded Mobile Canvas */}
      <div className="w-full h-full bg-white rounded-[38px] overflow-hidden relative flex flex-col pt-6 font-sans select-none border border-gray-100 shadow-inner">
        
        {/* Mobile Header / Signal */}
        <div className="px-5 py-2 flex justify-between items-center text-[10px] font-bold text-gray-400">
          <span>9:41 AM</span>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
            <span>Creditivoo Red</span>
          </div>
        </div>

        {/* Dynamic App Content */}
        <div className="flex-1 flex flex-col p-4 overflow-hidden relative">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.25 }}
                className="flex flex-col h-full justify-between"
              >
                <div>
                  <div className="flex justify-center my-2">
                    <div className="scale-75 origin-center">
                      <CreditivooLogo showText={false} className="h-10" />
                    </div>
                  </div>
                  
                  <h3 className="text-center font-bold text-gray-900 text-lg leading-tight mt-1">
                    Tu línea digital de compra IVOO
                  </h3>
                  <p className="text-center text-xs text-gray-500 mt-1 max-w-[210px] mx-auto">
                    Sin bancos ni papeleo tedioso. Una evaluación clara y transparente.
                  </p>

                  <div className="space-y-2 mt-4">
                    <div className="flex items-center gap-2.5 p-2 bg-gray-50 rounded-xl border border-gray-100">
                      <div className="p-1.5 bg-emerald-100 rounded-lg text-[#006B3F]">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <p className="text-[11px] font-bold text-gray-800">100% Protegido</p>
                        <p className="text-[9px] text-gray-500">Tus datos están encriptados</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2.5 p-2 bg-gray-50 rounded-xl border border-gray-100">
                      <div className="p-1.5 bg-emerald-100 rounded-lg text-[#006B3F]">
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <p className="text-[11px] font-bold text-gray-800">Tres Perfiles</p>
                        <p className="text-[9px] text-gray-500">Diseñado para tu necesidad</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <button
                    onClick={() => setStep(2)}
                    className="w-full py-2.5 bg-[#10D66B] hover:bg-[#00B555] text-white rounded-xl text-xs font-bold shadow-md shadow-[#10D66B]/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    Comenzar Solicitud
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <p className="text-center text-[9px] text-gray-400 mt-2">
                    Al continuar, aceptas la evaluación de perfil comercial.
                  </p>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
                className="flex flex-col h-full justify-between"
              >
                <div>
                  <span className="text-[9px] font-bold text-[#006B3F] bg-emerald-50 px-2 py-0.5 rounded-full">
                    Paso 2 de 5
                  </span>
                  <h3 className="font-bold text-gray-900 text-lg mt-1 text-left">
                    ¿Cuál es tu perfil?
                  </h3>
                  <p className="text-[11px] text-gray-500 mt-1 text-left">
                    Selecciona para quién se asignará la línea de compra IVOO.
                  </p>

                  <div className="space-y-2 mt-4">
                    {[
                      { id: 'mayorista', label: 'Mayorista / Negocio', desc: 'Comprar inventario o volumen' },
                      { id: 'emprendedor', label: 'Emprendedor Independiente', desc: 'Comercio por Instagram, WP o local' },
                      { id: 'nomina', label: 'Nómina Colaborador', desc: 'Socio o empleado de empresa' }
                    ].map((prof) => (
                      <div
                        key={prof.id}
                        onClick={() => setSelectedProfile(prof.id)}
                        className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between ${
                          selectedProfile === prof.id
                            ? 'border-[#10D66B] bg-emerald-50/50 ring-1 ring-[#10D66B]'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div>
                          <p className="text-[11px] font-bold text-gray-800">{prof.label}</p>
                          <p className="text-[9px] text-gray-500">{prof.desc}</p>
                        </div>
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                          selectedProfile === prof.id ? 'border-[#10D66B] bg-[#10D66B] text-white' : 'border-gray-300'
                        }`}>
                          {selectedProfile === prof.id && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => setStep(1)}
                    className="flex-1 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Atrás
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    className="flex-1 py-2 bg-[#10D66B] hover:bg-[#00B555] text-white rounded-xl text-xs font-bold shadow-md shadow-[#10D66B]/15 transition-all cursor-pointer"
                  >
                    Siguiente
                  </button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
                className="flex flex-col h-full justify-between"
              >
                <div>
                  <span className="text-[9px] font-bold text-[#006B3F] bg-emerald-50 px-2 py-0.5 rounded-full">
                    Paso 4 de 5
                  </span>
                  <h3 className="font-bold text-gray-900 text-base mt-1 text-left">
                    Soporte de actividad
                  </h3>
                  <p className="text-[10px] text-gray-500 mt-1 text-left">
                    Carga tus documentos en segundos para iniciar nuestra revisión manual.
                  </p>

                  <div className="mt-4 space-y-2.5">
                    <div className="border border-dashed border-gray-300 rounded-xl p-3 bg-gray-50/50 flex flex-col items-center justify-center">
                      <FileText className="w-6 h-6 text-gray-400 mb-1" />
                      <p className="text-[10px] font-semibold text-gray-700">Cédula de Identidad & RIF</p>
                      <p className="text-[8px] text-gray-400">Archivos PDF o fotos legibles (Max 10MB)</p>
                    </div>

                    <div className="border border-dashed border-gray-300 rounded-xl p-3 bg-gray-50/50 flex flex-col items-center justify-center">
                      <Smartphone className="w-6 h-6 text-gray-400 mb-1" />
                      <p className="text-[10px] font-semibold text-gray-700">Prueba de Actividad Comercial</p>
                      <p className="text-[8px] text-gray-400">Captura de WhatsApp, Instagram, catálogo o facturas</p>
                    </div>

                    {isSubmittingDoc && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[8px] text-gray-500">
                          <span>Subiendo archivos...</span>
                          <span className="font-bold">{docProgress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-[#10D66B] h-full transition-all duration-150" style={{ width: `${docProgress}%` }}></div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 flex gap-2">
                  <button
                    disabled={isSubmittingDoc}
                    onClick={() => setStep(2)}
                    className="flex-1 py-2 bg-gray-100 disabled:opacity-50 hover:bg-gray-200 text-gray-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Atrás
                  </button>
                  <button
                    disabled={isSubmittingDoc}
                    onClick={startDocUpload}
                    className="flex-1 py-2 bg-[#10D66B] disabled:opacity-50 hover:bg-[#00B555] text-white rounded-xl text-xs font-bold shadow-md shadow-[#10D66B]/15 transition-all cursor-pointer"
                  >
                    {isSubmittingDoc ? 'Cargando...' : 'Confirmar & Cargar'}
                  </button>
                </div>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col h-full justify-between items-center text-center"
              >
                <div className="my-auto py-2">
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center text-[#10D66B] mx-auto mb-3">
                    <Sparkles className="w-6 h-6 fill-current animate-bounce" />
                  </div>
                  
                  <span className="text-[10px] font-bold text-white bg-emerald-600 px-3 py-1 rounded-full inline-block">
                    ¡Solicitud Recibida!
                  </span>

                  <h3 className="font-bold text-gray-900 text-md mt-2.5 leading-tight">
                    Evaluación en Progreso
                  </h3>
                  
                  <p className="text-[10.5px] text-gray-500 mt-2 max-w-[210px] mx-auto">
                    Hemos recibido tus datos de perfil <strong className="text-gray-900 capitalize font-bold">{selectedProfile}</strong> con éxito.
                  </p>

                  <div className="mt-4 p-2.5 bg-emerald-50/50 border border-emerald-100 rounded-2xl mx-auto max-w-[220px]">
                    <p className="text-[9px] text-emerald-800 uppercase tracking-widest font-black">Línea Estimada Potencial</p>
                    <p className="text-xl font-black text-[#006B3F] mt-1">$1,500 USD</p>
                    <p className="text-[8px] text-gray-400 mt-0.5">Sujeto a validación manual de documentos</p>
                  </div>
                </div>

                <div className="w-full mt-2">
                  <button
                    onClick={resetSimulator}
                    className="w-full py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer"
                  >
                    Probar de Nuevo
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* FLOATING STATUS CARDS surrounding the mockup */}
      
      {/* Floating Card 1: Line Approved */}
      <div 
        className="absolute -left-12 top-10 bg-white/95 backdrop-blur-sm p-3 rounded-2xl shadow-xl border border-gray-100/80 max-w-[150px] z-10 hidden sm:block hover:translate-y-[-4px] transition-transform duration-300"
      >
        <div className="flex items-center gap-1.5 justify-start mb-1 text-[10px] text-gray-500 font-bold uppercase tracking-wider">
          <TrendingUp className="w-3.5 h-3.5 text-[#10D66B]" />
          <span>Línea Activa</span>
        </div>
        <p className="text-sm font-extrabold text-gray-900">$2,400.00</p>
        <p className="text-[9px] text-[#006B3F] font-semibold">Disponible en IVOO</p>
      </div>

      {/* Floating Card 2: Documents Received */}
      <div 
        className="absolute -right-16 top-1/4 bg-white/95 backdrop-blur-sm p-3 rounded-2xl shadow-xl border border-gray-100/80 max-w-[170px] z-10 hidden sm:block hover:translate-y-[-4px] transition-transform duration-300"
      >
        <div className="flex gap-2 items-center">
          <div className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></div>
          <span className="text-[9.5px] font-bold text-gray-800">Cédula & RIF</span>
        </div>
        <p className="text-[10px] text-gray-400 mt-1 leading-tight text-left">Documentos en revisión por analistas</p>
        <div className="mt-1.5">
          <StatusBadge status="pending" text="Revisión Manual" />
        </div>
      </div>

      {/* Floating Card 3: Benefit Active */}
      <div 
        className="absolute -left-14 bottom-1/4 bg-white/95 backdrop-blur-sm p-3 rounded-2xl shadow-xl border border-gray-100/80 max-w-[160px] z-10 hidden sm:block hover:translate-y-[-4px] transition-transform duration-300"
      >
        <div className="flex items-center gap-2">
          <div className="p-1 bg-indigo-50 text-indigo-600 rounded">
            <Building2 className="w-3.5 h-3.5" />
          </div>
          <div className="text-left">
            <p className="text-[10px] font-bold text-gray-800">Convenio Nómina</p>
            <p className="text-[8px] text-gray-400">Validado por tu Empresa</p>
          </div>
        </div>
      </div>
    </div>
  );
}
