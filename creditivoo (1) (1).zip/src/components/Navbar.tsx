/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, LogIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import CreditivooLogo from './CreditivooLogo';

interface NavbarProps {
  onCtaClick: () => void;
  onCompanyClick: () => void;
}

export default function Navbar({ onCtaClick, onCompanyClick }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Inicio', href: '#inicio' },
    { name: 'Soluciones', href: '#soluciones' },
    { name: 'Cómo funciona', href: '#como-funciona' },
    { name: 'Requisitos', href: '#requisitos' },
    { name: 'Empresas', href: '#empresas' },
    { name: 'FAQ', href: '#preguntas-frecuentes' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    const element = document.querySelector(href);
    if (element) {
      const offset = 80; // height of navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 backdrop-blur-md shadow-md border-b border-gray-100 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo link */}
          <a href="#inicio" className="flex items-center" onClick={(e) => handleLinkClick(e, '#inicio')}>
            <CreditivooLogo className="h-8 md:h-9" />
          </a>

          {/* Desktop Links */}
          <nav className="hidden lg:flex items-center space-x-7">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={(e) => handleLinkClick(e, item.href)}
                className="text-sm font-semibold text-gray-700 hover:text-[#10D66B] transition-colors relative group py-2"
              >
                {item.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#10D66B] transition-all group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* Desktop CTAs */}
          <div className="hidden lg:flex items-center space-x-4">
            <button
              onClick={() => alert('Acceso de clientes en desarrollo corporativo. En este MVP, complete el formulario de solicitud.')}
              className="text-gray-700 hover:text-[#10D66B] font-bold text-sm flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Iniciar sesión</span>
            </button>
            <button
              onClick={onCtaClick}
              className="bg-[#10D66B] hover:bg-[#00B555] text-white text-sm font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-[#10D66B]/15 hover:shadow-[#10D66B]/25 transition-all flex items-center gap-1.5 group cursor-pointer"
            >
              <span>Solicitar Creditivoo</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>

          {/* Mobile hamburger icon */}
          <div className="lg:hidden flex items-center space-x-3">
            <button
              onClick={() => alert('Próximamente disponible. Use el formulario de contacto para canalizar su solicitud.')}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <LogIn className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-gray-600 hover:text-[#10D66B] transition-colors focus:outline-none"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="lg:hidden bg-white border-b border-gray-100 shadow-xl overflow-hidden"
          >
            <div className="px-4 pt-3 pb-6 space-y-3">
              {menuItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={(e) => handleLinkClick(e, item.href)}
                  className="block px-3 py-2 rounded-lg text-base font-bold text-gray-700 hover:text-[#10D66B] hover:bg-emerald-50/50 transition-all"
                >
                  {item.name}
                </a>
              ))}
              
              <div className="pt-4 border-t border-gray-100 space-y-3 px-3">
                <button
                  onClick={() => {
                    setIsOpen(false);
                    alert('Acceso de clientes en desarrollo corporativo. En este MVP, complete el formulario de solicitud.');
                  }}
                  className="w-full py-2.5 flex items-center justify-center gap-2 bg-transparent border border-gray-200 text-gray-700 font-bold text-sm rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Iniciar sesión</span>
                </button>
                <button
                  onClick={() => {
                    setIsOpen(false);
                    onCtaClick();
                  }}
                  className="w-full bg-[#10D66B] hover:bg-[#00B555] text-white text-sm font-bold py-3 rounded-xl shadow-lg shadow-[#10D66B]/15 transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Solicitar Creditivoo</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
