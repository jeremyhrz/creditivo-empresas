/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileCheck2, ShieldAlert, BadgeInfo } from 'lucide-react';
import { RequirementTab } from '../types';
import { REQUIREMENTS } from '../landingData';

export default function RequirementTabs() {
  const [activeTab, setActiveTab] = useState<'mayorista' | 'emprendedor' | 'nomina' | 'empresas'>('mayorista');

  const currentTabInfo = REQUIREMENTS.find((req) => req.id === activeTab) || REQUIREMENTS[0];

  return (
    <div className="w-full bg-white rounded-3xl border border-gray-100 p-6 md:p-8 shadow-sm">
      {/* Scrollable Tab Controls */}
      <div className="flex border-b border-gray-100 overflow-x-auto scrollbar-none pb-2 mb-6 gap-2">
        {REQUIREMENTS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`whitespace-nowrap px-4 py-2.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-[#10D66B] text-white border-[#10D66B] shadow-md shadow-[#10D66B]/15'
                : 'bg-gray-50 text-gray-500 border-transparent hover:text-gray-700 hover:bg-gray-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Dynamic Animated Content Panel */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start"
        >
          {/* Tab Description Context */}
          <div className="lg:col-span-5 space-y-4">
            <h4 className="text-xl font-black text-gray-900 leading-tight">
              {currentTabInfo.title}
            </h4>
            <p className="text-sm text-gray-500 leading-relaxed">
              {currentTabInfo.description}
            </p>

            <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100/30 flex gap-3 text-left">
              <BadgeInfo className="w-5 h-5 text-[#006B3F] shrink-0 mt-0.5" />
              <p className="text-xs text-emerald-800 leading-relaxed">
                <strong>Análisis Personalizado:</strong> Recordamos que Creditivoo no es un banco. Los documentos suministrados son analizados manualmente para otorgar el máximo límite viable adaptado a tu capacidad real.
              </p>
            </div>
          </div>

          {/* Tab Document Bullets list */}
          <div className="lg:col-span-7 bg-gray-50/50 rounded-2xl p-5 md:p-6 border border-gray-100/60">
            <h5 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-1.5">
              <FileCheck2 className="w-4 h-4 text-[#10D66B]" />
              <span>Documentos a consignar</span>
            </h5>
            
            <ul className="space-y-3">
              {currentTabInfo.documents.map((doc, idx) => (
                <li key={idx} className="flex gap-3 text-sm text-gray-700 items-start">
                  <span className="mt-1 w-1.5 h-1.5 rounded-full bg-[#10D66B] shrink-0"></span>
                  <span className="leading-snug">{doc}</span>
                </li>
              ))}
            </ul>

            <p className="text-[11px] text-gray-400 mt-5 leading-relaxed italic flex gap-1.5 items-center">
              <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
              <span>*Los recaudos pueden variar levemente según el criterio del analista asignado.</span>
            </p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
