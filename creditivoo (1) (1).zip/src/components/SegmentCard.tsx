/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Check, ArrowRight, Award, TrendingUp, Smartphone, Building } from 'lucide-react';
import { Segment } from '../types';

interface SegmentCardProps {
  key?: any;
  segment: Segment;
  onSelect: (id: 'mayorista' | 'emprendedor' | 'nomina') => void;
}

export default function SegmentCard({ segment, onSelect }: SegmentCardProps) {
  // Styles based on badgeStyle
  const themeStyles = {
    emerald: {
      bg: 'hover:border-emerald-200 hover:shadow-emerald-100/50 hover:bg-emerald-50/[0.15]',
      badge: 'bg-emerald-50 text-emerald-700 border-emerald-200/50',
      icon: 'text-emerald-600 bg-emerald-50',
      tagline: 'text-emerald-700',
      button: 'bg-emerald-600 hover:bg-emerald-700 text-white hover:shadow-emerald-200',
      decorative: 'from-emerald-400/20 to-transparent'
    },
    cyan: {
      bg: 'hover:border-cyan-200 hover:shadow-cyan-100/50 hover:bg-cyan-50/[0.15]',
      badge: 'bg-cyan-50 text-cyan-700 border-cyan-200/50',
      icon: 'text-cyan-600 bg-cyan-50',
      tagline: 'text-cyan-700',
      button: 'bg-cyan-600 hover:bg-cyan-700 text-white hover:shadow-cyan-200',
      decorative: 'from-cyan-400/20 to-transparent'
    },
    indigo: {
      bg: 'hover:border-indigo-200 hover:shadow-indigo-100/50 hover:bg-[#eaeefc]/20',
      badge: 'bg-indigo-50 text-indigo-700 border-indigo-200/50',
      icon: 'text-indigo-600 bg-indigo-50',
      tagline: 'text-indigo-700',
      button: 'bg-[#006B3F] hover:bg-[#005530] text-white hover:shadow-green-200',
      decorative: 'from-indigo-400/20 to-transparent'
    }
  }[segment.badgeStyle || 'emerald'];

  const getIcon = () => {
    switch (segment.id) {
      case 'mayorista':
        return <TrendingUp className="w-5 h-5" />;
      case 'emprendedor':
        return <Smartphone className="w-5 h-5" />;
      case 'nomina':
        return <Building className="w-5 h-5" />;
      default:
        return <Award className="w-5 h-5" />;
    }
  };

  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={`relative h-full flex flex-col justify-between p-6 sm:p-8 bg-white rounded-3xl border border-gray-100 shadow-sm transition-all duration-300 ${themeStyles.bg}`}
    >
      {/* Absolute background accent line */}
      <span className={`absolute top-0 inset-x-0 h-1 rounded-t-3xl bg-gradient-to-r ${themeStyles.decorative}`}></span>

      <div>
        {/* Card Header & Badge */}
        <div className="flex justify-between items-start gap-3 mb-5">
          <div className={`p-3 rounded-2xl ${themeStyles.icon} flex items-center justify-center`}>
            {getIcon()}
          </div>
          <span className={`px-3 py-1 text-[11px] font-bold tracking-wide uppercase rounded-full border ${themeStyles.badge}`}>
            {segment.badgeText}
          </span>
        </div>

        {/* Card Titles */}
        <p className={`text-xs font-bold uppercase tracking-wider ${themeStyles.tagline} mb-1.5`}>
          {segment.tagline}
        </p>
        <h3 className="text-2xl font-black text-gray-900 tracking-tight leading-none mb-3">
          {segment.title}
        </h3>
        <p className="text-sm text-gray-500 leading-relaxed mb-6">
          {segment.description}
        </p>

        {/* Card Bullets */}
        <div className="border-t border-gray-100 pt-5 mb-8">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">
            Características destacadas
          </p>
          <ul className="space-y-3">
            {segment.bullets.map((bullet, index) => (
              <li key={index} className="flex items-start gap-2.5 text-sm text-gray-600">
                <span className="mt-0.5 p-0.5 bg-emerald-50 text-[#10D66B] rounded-full flex-shrink-0">
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </span>
                <span className="leading-tight">{bullet}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Card Button */}
      <button
        onClick={() => onSelect(segment.id)}
        className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm tracking-wide transition-all duration-205 flex items-center justify-center gap-1.5 group cursor-pointer shadow-md ${themeStyles.button}`}
      >
        <span>{segment.ctaText}</span>
        <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
      </button>
    </motion.div>
  );
}
