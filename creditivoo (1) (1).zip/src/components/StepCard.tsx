/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Step } from '../types';

interface StepCardProps {
  key?: any;
  step: Step;
}

export default function StepCard({ step }: StepCardProps) {
  return (
    <div className="relative flex flex-col items-center text-center p-6 bg-white border border-gray-100 rounded-3xl hover:shadow-md transition-all duration-300 group">
      {/* Step Number Circle */}
      <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-12 h-12 rounded-full bg-[#10D66B] hover:bg-[#00B555] text-white font-black text-lg flex items-center justify-center shadow-lg shadow-[#10D66B]/20 select-none transition-all group-hover:scale-105">
        {step.number}
      </div>

      <div className="mt-6">
        <h4 className="font-extrabold text-gray-900 text-base leading-snug mb-2 group-hover:text-[#006B3F] transition-colors">
          {step.title}
        </h4>
        <p className="text-xs text-gray-500 leading-relaxed">
          {step.description}
        </p>
      </div>
    </div>
  );
}
